
class Humano{

    constructor(){
        alert('Hola desde el contructor');
        
    }

}