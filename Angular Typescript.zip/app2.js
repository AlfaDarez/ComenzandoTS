"use strict";
var datos = /** @class */ (function () {
    function datos() {
        console.log('Ingresando desde Otra clase');
    }
    return datos;
}());
