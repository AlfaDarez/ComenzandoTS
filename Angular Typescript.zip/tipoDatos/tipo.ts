
//datos enteros 
let numero:number;
numero=12;

//String 
let texto:string;
texto="Hola Mundo";

//Boolean 
let verdadero:boolean;
let falso:boolean;
verdadero=true;
falso=false;

//Cualquier tipo de dato;
let otrosDatos:any;
otrosDatos="texto";
otrosDatos=232;
otrosDatos=false;

