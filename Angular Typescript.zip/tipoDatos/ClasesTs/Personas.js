"use strict";
var Persona = /** @class */ (function () {
    function Persona(numero) {
        alert('El Numero de Personas Es:' + numero);
    }
    return Persona;
}());
var persona = new Persona(12);
