
    class Persona{
        

        constructor(numero:number){
            alert('El Numero de Personas Es:'+numero);
            
        }    

    }

    let persona = new Persona(12);