"use strict";
var Calculadora = /** @class */ (function () {
    function Calculadora(n1, n2) {
        console.log(n1 + n2);
    }
    return Calculadora;
}());
var suma = new Calculadora(12, 34);
var suma2 = new Calculadora(30, 30);
