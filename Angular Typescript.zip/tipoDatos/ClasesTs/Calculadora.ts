

class Calculadora{
    constructor(n1:number,n2:number){
        console.log(n1+n2);
    }
}



let suma= new Calculadora(12,34);
let suma2=new Calculadora(30,30);