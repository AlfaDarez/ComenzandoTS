//arreglo de tipo texto 
let arrayText:string[];

arrayText=["Hola","Mundo"];

//arreglo de tipo Numerico 
let arrayNumero:number[];

arrayNumero=[12,33,43,2];




//arreglo de tipo Boolen 
let arrayBoo:boolean[];
arrayBoo=[false,true,false,false ,true];

// arreglo de cualquier tipo de datos

let arrayAny:any[];

arrayAny=["Texto",12212,true,'Numeros'];

