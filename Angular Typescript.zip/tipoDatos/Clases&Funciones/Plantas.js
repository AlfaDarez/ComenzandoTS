"use strict";
var Plantas = /** @class */ (function () {
    function Plantas(nom, flora) {
        this.nombre = nom;
        this.flor = flora;
        if (this.flor == true) {
            this.esFlor();
        }
        else {
            this.esPlanta();
        }
    }
    Plantas.prototype.esFlor = function () {
        alert('La Planta ' + this.nombre + ' Tiene Muchas Flores Bonitas');
    };
    Plantas.prototype.esPlanta = function () {
        alert('ES UNA PLANTA SIN FLORES');
    };
    return Plantas;
}());
