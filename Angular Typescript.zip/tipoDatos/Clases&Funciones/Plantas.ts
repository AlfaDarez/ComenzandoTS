class Plantas{

    nombre:string;
    flor:boolean;

    constructor(nom:string,flora:boolean){
        this.nombre=nom;
        this.flor=flora;
        if(this.flor==true){
            this.esFlor();
        }else{
            this.esPlanta();
        }
    }

     esFlor(){
        alert('La Planta '+this.nombre+' Tiene Muchas Flores Bonitas');
     }

     esPlanta(){
         alert('ES UNA PLANTA SIN FLORES');
     }



   

}