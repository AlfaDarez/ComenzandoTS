"use strict";
//datos enteros 
var numero;
numero = 12;
//String 
var texto;
texto = "Hola Mundo";
//Boolean 
var verdadero;
var falso;
verdadero = true;
falso = false;
//Cualquier tipo de dato;
var otrosDatos;
otrosDatos = "texto";
otrosDatos = 232;
otrosDatos = false;
