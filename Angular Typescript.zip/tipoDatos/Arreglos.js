"use strict";
//arreglo de tipo texto 
var arrayText;
arrayText = ["Hola", "Mundo"];
//arreglo de tipo Numerico 
var arrayNumero;
arrayNumero = [12, 33, 43, 2];
//arreglo de tipo Boolen 
var arrayBoo;
arrayBoo = [false, true, false, false, true];
// arreglo de cualquier tipo de datos
var arrayAny;
arrayAny = ["Texto", 12212, true, 'Numeros'];
