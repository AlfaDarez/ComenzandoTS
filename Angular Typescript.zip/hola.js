"use strict";
var Humano = /** @class */ (function () {
    function Humano() {
        alert('Hola desde el contructor');
    }
    return Humano;
}());
