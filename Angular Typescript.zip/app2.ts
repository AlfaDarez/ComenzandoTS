class datos{
    constructor(){
        console.log('Ingresando desde Otra clase');
    }
}